import { useEffect, useRef, useState } from 'react';
import { NavLink, useNavigate, useParams } from 'react-router-dom';
import { userApi } from '../features/user/api/userApi';
import type { UserProfile } from '../features/user/types/user.types';
import { Avatar } from '../shared/components/ui/Avatar';
import { Button } from '../shared/components/ui/Button';
import { Dropdown } from '../shared/components/ui/Dropdown';
import { ScrollFade } from '../shared/components/ui/ScrollFade';
import { ProfileHeaderSkeleton, PostSkeleton } from '../shared/components/ui/Skeleton';
import { ErrorState } from '../shared/components/ui/ErrorState';
import { EmptyState } from '../shared/components/ui/EmptyState';
import {
  SearchIcon,
  MoreHorizontalIcon,
  LogoIcon,
  MenuIcon,
  BarChartIcon,
  CreateThreadIcon,
  FollowSuggestIcon,
} from '../shared/components/icons/Icons';
import { useAuth } from '../features/auth/store/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useUserPosts } from '../features/post/hooks/useUserPosts';
import { PostCard } from '../features/post/components/PostCard';
import { EditProfileModal } from '../features/user/components/EditProfileModal';
import { CreatePostModal } from '../features/post/components/CreatePostModal';

const PROFILE_TABS = [
  { key: 'posts',   label: 'Thread' },
  { key: 'replies', label: 'Câu trả lời' },
  { key: 'media',   label: 'File phương tiện' },
  { key: 'reposts', label: 'Bài đăng lại' },
];

const COMPLETION_CARDS = [
  {
    key: 'create',
    icon: <CreateThreadIcon size={32} />,
    title: 'Tạo thread',
    desc: 'Chia sẻ suy nghĩ hoạt động nổi bật mới đây của bạn.',
    cta: 'Tạo',
    action: 'compose',
  },
  {
    key: 'follow',
    icon: <FollowSuggestIcon size={32} />,
    title: 'Theo dõi 10 trang cá nhân',
    desc: 'Hãy lấp đầy feed bằng những thread bạn quan tâm.',
    cta: 'Xem trang cá nhân',
    action: 'search',
  },
];

export const ProfilePage = () => {
  const { username } = useParams<{ username: string }>();
  const navigate     = useNavigate();
  const { user: me } = useAuth();
  const { t }        = useLanguage();

  const [profile, setProfile]         = useState<UserProfile | null>(null);
  const [loadError, setLoadError]     = useState(false);
  const [isLoading, setIsLoading]     = useState(true);
  const [editOpen, setEditOpen]       = useState(false);
  const [composeOpen, setComposeOpen] = useState(false);
  const [activeTab, setActiveTab]     = useState('posts');
  const tabsRef = useRef<HTMLDivElement>(null);

  const {
    posts, isLoading: postsLoading,
    toggleLike, toggleRepost, toggleBookmark, removePost,
  } = useUserPosts(username);

  const fetchProfile = () => {
    if (!username) return;
    setIsLoading(true);
    setLoadError(false);
    userApi
      .getProfile(username)
      .then(setProfile)
      .catch(() => setLoadError(true))
      .finally(() => setIsLoading(false));
  };

  useEffect(fetchProfile, [username]);
  useEffect(() => setActiveTab('posts'), [username]);

  if (isLoading)             return <ProfileHeaderSkeleton />;
  if (loadError || !profile) return <ErrorState message={t('user_not_found')} onRetry={fetchProfile} />;

  const isMe = me?.username === username;

  const toggleFollow = async () => {
    profile.isFollowing
      ? await userApi.unfollow(profile.id)
      : await userApi.follow(profile.id);
    setProfile(p =>
      p
        ? { ...p, isFollowing: !p.isFollowing, followersCount: p.followersCount + (p.isFollowing ? -1 : 1) }
        : p,
    );
  };

  const completionLeft = 4;

  return (
    <div className="animate-fade-in min-h-screen bg-background">

      {/* ── Sticky top bar ─────────────────────────────── */}
      <div className="sticky top-0 z-20 flex items-center justify-between px-4 py-3 bg-background/90 backdrop-blur-md">
        <Dropdown
          align="left"
          menuClassName="rounded-2xl shadow-2xl ring-1 ring-black/5 dark:ring-white/10"
          trigger={
            <button className="cursor-pointer rounded-full p-1.5 text-text hover:bg-surface-hover">
              <MenuIcon size={22} />
            </button>
          }
          items={
            isMe
              ? [
                  { label: t('nav_settings'), onClick: () => navigate('/settings') },
                  { label: t('nav_logout'), danger: true, onClick: () => navigate('/login') },
                ]
              : [
                  { label: t('block_user'), onClick: () => {} },
                  { label: t('report'), danger: true, onClick: () => {} },
                ]
          }
        />
        <NavLink to="/" className="flex items-center">
          <LogoIcon size={28} />
        </NavLink>
        <button
          onClick={() => navigate('/search')}
          className="cursor-pointer rounded-full p-1.5 text-text hover:bg-surface-hover"
        >
          <SearchIcon size={22} />
        </button>
      </div>

      {/* ── Profile block ───────────────────────────────── */}
      <div className="px-4 pt-4 pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex flex-col gap-0.5">
            <h1 className="text-[22px] font-bold text-text leading-tight">{profile.displayName}</h1>
            <p className="text-[15px] text-text">
              {profile.username}
              {profile.isVerified && <span className="ml-1 text-primary">✓</span>}
            </p>
          </div>
          <Avatar src={profile.avatarUrl} name={profile.displayName} size="xl" />
        </div>

        {profile.bio && (
          <p className="mt-3 text-[14px] text-text leading-snug whitespace-pre-wrap">{profile.bio}</p>
        )}

        <div className="mt-3 flex items-center justify-between">
          <button
            onClick={() => navigate(`/profile/${username}/followers`)}
            className="cursor-pointer text-[14px] text-secondary hover:underline"
          >
            <span className="font-semibold text-text">{profile.followersCount.toLocaleString()}</span>{' '}
            {t('followers_label')}
          </button>
          <button
            onClick={() => navigate(`/profile/${username}/followers`)}
            className="cursor-pointer rounded-lg p-1.5 text-secondary hover:bg-surface-hover hover:text-text"
            title="Thống kê"
          >
            <BarChartIcon size={20} />
          </button>
        </div>

        <div className="mt-3">
          {isMe ? (
            <Button variant="outline" className="w-full rounded-xl font-semibold" onClick={() => setEditOpen(true)}>
              {t('edit_profile_button')}
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button
                variant={profile.isFollowing ? 'outline' : 'primary'}
                className="flex-1 rounded-xl font-semibold"
                onClick={toggleFollow}
              >
                {profile.isFollowing ? t('following') : t('follow')}
              </Button>
              <Button variant="outline" className="flex-1 rounded-xl font-semibold">
                {t('mention') ?? 'Nhắc đến'}
              </Button>
              <button className="cursor-pointer rounded-xl border border-border px-3 py-2 text-secondary hover:bg-surface-hover">
                <MoreHorizontalIcon size={18} />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ── Tabs — dùng ScrollFade để hiện chỉ báo cuộn ngang ── */}
      <div className="border-b border-border" ref={tabsRef}>
        <ScrollFade
          className="flex"
          fadeColor="var(--color-background)"
          fadeWidth={32}
        >
          {PROFILE_TABS.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`relative shrink-0 cursor-pointer px-5 py-3.5 text-sm font-semibold whitespace-nowrap transition-colors ${
                activeTab === tab.key ? 'text-text' : 'text-secondary hover:text-text'
              }`}
            >
              {tab.label}
              {activeTab === tab.key && (
                <span className="absolute inset-x-0 bottom-0 h-[2px] bg-text" />
              )}
            </button>
          ))}
        </ScrollFade>
      </div>

      {/* ── Quick compose bar (own profile) ─────────────── */}
      {isMe && activeTab === 'posts' && (
        <div
          className="flex items-center gap-3 px-4 py-3 border-b border-border cursor-pointer"
          onClick={() => setComposeOpen(true)}
        >
          <Avatar src={me?.avatarUrl} name={me?.displayName ?? ''} size="sm" />
          <span className="flex-1 text-sm text-secondary select-none">Có gì mới?</span>
          <button
            className="cursor-pointer rounded-xl bg-text px-4 py-1.5 text-sm font-semibold text-background hover:opacity-90 transition-opacity"
            onClick={e => { e.stopPropagation(); setComposeOpen(true); }}
          >
            Đăng
          </button>
        </div>
      )}

      {/* ── Tab content ─────────────────────────────────── */}
      {activeTab === 'posts' && (
        <>
          {/* Completion cards — dùng ScrollFade để hiện gradient chỉ báo */}
          {isMe && posts.length === 0 && !postsLoading && (
            <div className="px-4 py-4">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-[13px] font-semibold text-text">Hoàn tất trang cá nhân</span>
                <span className="text-[13px] font-semibold text-text">Còn {completionLeft}</span>
              </div>
              {/* ScrollFade: hiện gradient phải khi còn card bị ẩn */}
              <ScrollFade
                className="flex gap-3 pb-2"
                fadeColor="var(--color-background)"
                fadeWidth={48}
              >
                {COMPLETION_CARDS.map(card => (
                  <div
                    key={card.key}
                    className="shrink-0 w-44 rounded-2xl border border-border bg-surface p-4 flex flex-col gap-3"
                  >
                    <span className="text-secondary">{card.icon}</span>
                    <div>
                      <p className="text-[13px] font-semibold text-text leading-snug">{card.title}</p>
                      <p className="mt-1 text-[12px] text-secondary leading-snug line-clamp-3">{card.desc}</p>
                    </div>
                    <button
                      onClick={() => card.action === 'compose' ? setComposeOpen(true) : navigate('/search')}
                      className="w-full cursor-pointer rounded-xl bg-text py-2 text-[13px] font-bold text-background hover:opacity-90 transition-opacity"
                    >
                      {card.cta}
                    </button>
                  </div>
                ))}
              </ScrollFade>
            </div>
          )}

          {postsLoading && Array.from({ length: 3 }).map((_, i) => <PostSkeleton key={i} />)}
          {!postsLoading && posts.length > 0 &&
            posts.map(p => (
              <PostCard
                key={p.id}
                post={p}
                onLike={toggleLike}
                onRepost={toggleRepost}
                onBookmark={toggleBookmark}
                onDelete={removePost}
              />
            ))
          }
          {!postsLoading && posts.length === 0 && isMe     && <div className="py-8" />}
          {!postsLoading && posts.length === 0 && !isMe    && (
            <EmptyState title={t('no_posts_title')} description={t('no_posts_desc_other')} />
          )}
        </>
      )}

      {activeTab === 'replies' && (
        <EmptyState title={t('replies_empty_title')} description={t('replies_empty_desc')} />
      )}
      {activeTab === 'media' && (
        <EmptyState title="Chưa có file phương tiện" description="Ảnh và video sẽ xuất hiện ở đây." />
      )}
      {activeTab === 'reposts' && (
        <EmptyState title="Chưa có bài đăng lại" description="Bài đăng lại sẽ xuất hiện ở đây." />
      )}

      {isMe && (
        <footer className="mt-8 pb-28 text-center">
          <p className="text-[11px] text-secondary leading-relaxed">
            © 2026{' '}
            <span className="text-primary cursor-pointer hover:underline">Điều khoản của ConnectHub</span>
            {'  '}
            <span className="text-secondary cursor-pointer hover:underline">Chính sách quyền riêng tư</span>
            <br />
            <span className="text-secondary cursor-pointer hover:underline">Chính sách cookie</span>
          </p>
        </footer>
      )}

      {isMe && (
        <EditProfileModal
          isOpen={editOpen}
          onClose={() => setEditOpen(false)}
          profile={profile}
          onSaved={updated => setProfile(updated)}
        />
      )}
      <CreatePostModal
        isOpen={composeOpen}
        onClose={() => setComposeOpen(false)}
        onCreated={() => navigate('/')}
      />
    </div>
  );
};
