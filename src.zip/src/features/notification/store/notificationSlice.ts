import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { RootState } from "../../../app/store";
import type { NotificationResponse } from "../types/notification.types";

interface NotificationState {
  items: NotificationResponse[];
  cursor: string | null;
  hasNext: boolean;
  isLoading: boolean;
  error: string | null;
  unreadCount: number;
}

const initialState: NotificationState = {
  items: [],
  cursor: null,
  hasNext: false,
  isLoading: false,
  error: null,
  unreadCount: 0,
};

export const notificationSlice = createSlice({
  name: "notification",
  initialState,
  reducers: {
    fetchStart: (state) => {
      state.isLoading = true;
      state.error = null;
    },
    fetchError: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.error = action.payload;
    },
    /** reset=true: thay toàn bộ list (load lần đầu / refetch). reset=false: nối thêm (load more) */
    fetchSuccess: (
      state,
      action: PayloadAction<{
        items: NotificationResponse[];
        cursor: string | null;
        hasNext: boolean;
        reset: boolean;
      }>,
    ) => {
      const { items, cursor, hasNext, reset } = action.payload;
      state.items = reset ? items : [...state.items, ...items];
      state.cursor = cursor;
      state.hasNext = hasNext;
      state.isLoading = false;
      state.error = null;
    },
    /** Thêm 1 notification nhận realtime qua WebSocket lên đầu danh sách */
    prependRealtime: (state, action: PayloadAction<NotificationResponse>) => {
      if (state.items.some((n) => n.id === action.payload.id)) return;
      state.items.unshift(action.payload);
      if (!action.payload.read) {
        state.unreadCount += 1;
      }
    },
    markReadLocal: (state, action: PayloadAction<string>) => {
      const n = state.items.find((n) => n.id === action.payload);
      if (n && !n.read) {
        n.read = true;
        state.unreadCount = Math.max(0, state.unreadCount - 1);
      }
    },
    markAllReadLocal: (state) => {
      state.items.forEach((n) => (n.read = true));
      state.unreadCount = 0;
    },
    reset: () => initialState,
    setUnreadCount: (state, action: PayloadAction<number>) => {
      state.unreadCount = action.payload;
    },
  },
});

export const {
  fetchStart,
  fetchError,
  fetchSuccess,
  prependRealtime,
  markReadLocal,
  markAllReadLocal,
  setUnreadCount,
  reset: resetNotifications,
} = notificationSlice.actions;

export const selectNotifications = (state: RootState) =>
  state.notification.items;
export const selectNotificationCursor = (state: RootState) =>
  state.notification.cursor;
export const selectNotificationHasNext = (state: RootState) =>
  state.notification.hasNext;
export const selectNotificationLoading = (state: RootState) =>
  state.notification.isLoading;
export const selectNotificationError = (state: RootState) =>
  state.notification.error;
export const selectUnreadCount = (state: RootState) =>
  state.notification.unreadCount;

export default notificationSlice.reducer;
