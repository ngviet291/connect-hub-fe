import { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch } from "../../../app/store";
import { stompClient } from "../../../config/stompClient";
import { useAuth } from "../../auth/store/AuthContext";
import {
  fetchStart,
  fetchSuccess,
  fetchError,
  prependRealtime,
  markReadLocal,
  markAllReadLocal,
  selectNotifications,
  selectNotificationCursor,
  selectNotificationHasNext,
  selectNotificationLoading,
  selectNotificationError,
  selectUnreadCount,
  setUnreadCount,
} from "../store/notificationSlice";
import { notificationService } from "../services/notificationService";
import type { NotificationResponse } from "../types/notification.types";

// Nhiều component (NotificationDropdown, NotificationsPage) cùng gọi hook này song song.
// Chỉ mở 1 subscription WS thực sự — đếm số "người dùng" đang active, chỉ unsubscribe
// khi không còn ai dùng nữa (tránh 1 component unmount làm mất realtime của component còn lại).
let subscriberCount = 0;
let unsubscribeWs: (() => void) | null = null;

export function useNotifications() {
  const dispatch = useDispatch<AppDispatch>();
  const { user } = useAuth();

  const notifications = useSelector(selectNotifications);
  const cursor = useSelector(selectNotificationCursor);
  const hasMore = useSelector(selectNotificationHasNext);
  const isLoading = useSelector(selectNotificationLoading);
  const error = useSelector(selectNotificationError);
  const unreadCount = useSelector(selectUnreadCount);

  const fetchAll = useCallback(async () => {
    dispatch(fetchStart());
    try {
      const page = await notificationService.getNotifications();
      dispatch(
        fetchSuccess({
          items: page.content,
          cursor: page.nextCursor,
          hasNext: page.hasNext,
          reset: true,
        }),
      );
      const { unreadCount } = await notificationService.countUnread();
      dispatch(setUnreadCount(unreadCount));
    } catch (e) {
      dispatch(
        fetchError(
          e instanceof Error ? e.message : "Failed to load notifications",
        ),
      );
    }
  }, [dispatch]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  // Realtime qua WS — ref-counted subscribe, tách khỏi lifecycle của từng component gọi hook
  useEffect(() => {
    if (!user) return;

    subscriberCount += 1;
    stompClient.connect();
    if (!unsubscribeWs) {
      unsubscribeWs = stompClient.subscribe(
        "/user/queue/notifications",
        (body: unknown) => {
          dispatch(prependRealtime(body as NotificationResponse));
        },
      );
    }

    return () => {
      subscriberCount -= 1;
      if (subscriberCount <= 0) {
        unsubscribeWs?.();
        unsubscribeWs = null;
        subscriberCount = 0;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const loadMore = async () => {
    if (!hasMore || !cursor) return;
    try {
      const page = await notificationService.getNotifications(cursor);
      dispatch(
        fetchSuccess({
          items: page.content,
          cursor: page.nextCursor,
          hasNext: page.hasNext,
          reset: false,
        }),
      );
    } catch (e) {
      dispatch(
        fetchError(e instanceof Error ? e.message : "Failed to load more"),
      );
    }
  };

  const markAsRead = useCallback(
    (id: string) => {
      dispatch(markReadLocal(id));
      notificationService.markAsRead(id);
    },
    [dispatch],
  );

  const markAllAsRead = useCallback(() => {
    dispatch(markAllReadLocal());
    notificationService.markAllAsRead();
  }, [dispatch]);

  const fetchUnreadCount = useCallback(async () => {
    try {
      const { unreadCount } = await notificationService.countUnread();
      dispatch(setUnreadCount(unreadCount));
    } catch (e) {
      // có thể bỏ qua lỗi nhẹ, không cần fetchError vì đây chỉ là badge số
    }
  }, [dispatch]);
  return {
    notifications,
    isLoading,
    error,
    unreadCount,
    hasMore,
    loadMore,
    markAsRead,
    markAllAsRead,
    fetchUnreadCount,
    refetch: fetchAll,
  };
}
